SOHA AMIN — Birthday Website
=============================

Files:
- index.html
- images/memory-1.jpg through memory-10.jpg

To publish free with GitHub Pages:
1. Create a public GitHub repository.
2. Upload index.html and the images folder.
3. Open Settings -> Pages.
4. Under "Build and deployment", choose "Deploy from a branch".
5. Select the main branch and the / (root) folder, then Save.
6. GitHub will give you a shareable website address.

The "Play Perfect" button opens a YouTube search for Ed Sheeran's official song so the site does not redistribute copyrighted audio.
